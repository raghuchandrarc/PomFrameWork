# Page Object model Test automation framework using Selenium with Java, TestNG and Maven-
This is a sample project to demonstrate what is page object model framework and how it can used in selenium to automate any application.
TestNG is used as test framework.

Dependency
Java
Maven

###libraries used
Selenium
TestNG
log4j
Extent Reports

